This software includes portions of code derived from mynewt-nimble project. See [NOTICE](NOTICE) file for details.
